#include <iostream>
using namespace std;
class Exchange
{
public:
	void operator()(int&, int&);
};

void Exchange::operator()(int& x, int& y)
{
	int t;
	t = x;
	x = y;
	y = t;
}

int main()
{
	Exchange swap;
	int i = 20;
	int j = 30;

	cout << "Before swap:i=" << i << ", j=" << j << endl;
	swap(i, j);
	cout << "After swap:i=" << i << ", j=" << j << endl;
	return 0;
}