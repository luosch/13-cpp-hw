#include <string>
#include <iostream>
using namespace std;

class Fruit;
ostream& operator <<(ostream& out, const Fruit& x);
istream& operator >>(istream& in,  Fruit& x);

class Fruit
{

public:
	Fruit();

	friend ostream& operator << (ostream& out, const Fruit& x);
	friend istream& operator >> (istream& in,  Fruit& x);


private:
	string name;
	string color;
};





