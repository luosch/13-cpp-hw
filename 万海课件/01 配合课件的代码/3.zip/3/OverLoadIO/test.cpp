#include <iostream>
#include "Fruit.h"

using namespace std;

int main()
{
     Fruit fruit1;

	 cout << fruit1;

	 cin >> fruit1;

	 cout << fruit1;

	 cout << "Finished!" << endl;

	 return 0;
}