#include <iostream>
#include "Fruit.h"

using namespace std;

Fruit::Fruit()
{
	name = "apple";
	color = "green";
}

ostream& operator << ( ostream& out, const Fruit& x)
{
	cout << "name: " << x.name << "  color: " <<  x.color << endl;

	return out;
}

istream& operator >> (istream& in, Fruit& x)
{
	cout << "Please enter the name: " << endl;
	cin >> x.name;

	cout << "Please enter the color: " << endl;
	cin >> x.color;

	return in;
}
