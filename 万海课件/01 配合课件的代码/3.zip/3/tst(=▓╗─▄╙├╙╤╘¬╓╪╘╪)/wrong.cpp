#include <iostream>
using namespace std;

class COmplex;

COmplex operator + (COmplex &a,COmplex &b);
COmplex operator - (COmplex &a,COmplex &b);
COmplex operator * (COmplex &a,COmplex &b);
COmplex operator / (COmplex &a,COmplex &b);
COmplex operator = (COmplex &a,COmplex &b);
void operator += (COmplex &a,COmplex &b);
void operator -= (COmplex &a,COmplex &b);
void operator *= (COmplex &a,COmplex &b);
void operator /= (COmplex &a,COmplex &b);

class COmplex
{
public:
	COmplex(double a=1,double b=1);
	friend COmplex operator + (COmplex &a,COmplex &b);
	friend COmplex operator - (COmplex &a,COmplex &b);
	friend COmplex operator * (COmplex &a,COmplex &b);
	friend COmplex operator / (COmplex &a,COmplex &b);
	friend void operator = (COmplex &a,COmplex &b);
	friend void operator +=(COmplex &a,COmplex &b);
	friend void operator -=(COmplex &a,COmplex &b);
	friend void operator *=(COmplex &a,COmplex &b);
	friend void operator /=(COmplex &a,COmplex &b);
	void print(COmplex &a);

private:
	int r;
	int m;
};

COmplex::COmplex(double a,double b)
{
	r=a;
	m=b;
}

COmplex operator + (COmplex &a,COmplex &b)
{
	COmplex temp;
	temp.r=a.r+b.r;
	temp.m=a.m+b.m;
	return temp;
}

COmplex operator - (COmplex &a,COmplex &b)
{
	COmplex temp;
	temp.r=a.r-b.r;
	temp.m=a.m-b.m;
	return temp;
}
COmplex operator * (COmplex &a,COmplex &b)
{
	COmplex temp;
	temp.r=a.r*b.r-a.m*b.m;
	temp.m=a.m*b.r+a.r*b.m;
	return temp;
}
COmplex operator / (COmplex &a,COmplex &b)
{
	COmplex temp;
	b.m=-b.m;
	temp=a*b;
	temp.m=temp.m/(b.m*b.m+b.r*b.r);
	temp.r=temp.r/(b.m*b.m+b.r*b.r);
	return temp;
}
COmplex operator = (COmplex &a,COmplex &b)
{
	COmplex temp;
	
	temp.r=b.r;
	temp.m=b.m;

	return temp;
}
void operator += (COmplex &a,COmplex &b)
{
	a=a+b;
}
void operator -= (COmplex &a,COmplex &b)
{
	a=a-b;
}
void operator *= (COmplex &a,COmplex &b)
{
	a=a*b;
}
void operator /= (COmplex &a,COmplex &b)
{
	a=a/b;
}

void COmplex::print(COmplex &a)
{
	cout <<a.r<<"+"<<a.m<<"i"<<endl;
}

int main()
{
	COmplex a(2,3);
    COmplex b(2,1);
	a.print(a);
	a=a+b;
	a.print(a);
	return 0;

}


