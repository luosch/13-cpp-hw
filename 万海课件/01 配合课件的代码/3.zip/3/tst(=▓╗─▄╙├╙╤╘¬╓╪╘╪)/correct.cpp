#include <iostream>
using namespace std;

class COMPLEX;

COMPLEX operator + (COMPLEX &a,COMPLEX &b);
COMPLEX operator - (COMPLEX &a,COMPLEX &b);
COMPLEX operator * (COMPLEX &a,COMPLEX &b);
COMPLEX operator / (COMPLEX &a,COMPLEX &b);

void operator += (COMPLEX &a,COMPLEX &b);
void operator -= (COMPLEX &a,COMPLEX &b);
void operator *= (COMPLEX &a,COMPLEX &b);
void operator /= (COMPLEX &a,COMPLEX &b);

class COMPLEX
{
public:
	COMPLEX(double a=1,double b=1);
	friend COMPLEX operator + (COMPLEX &a,COMPLEX &b);
	friend COMPLEX operator - (COMPLEX &a,COMPLEX &b);
	friend COMPLEX operator * (COMPLEX &a,COMPLEX &b);
	friend COMPLEX operator / (COMPLEX &a,COMPLEX &b);
	COMPLEX operator = (COMPLEX &b);
	friend void operator +=(COMPLEX &a,COMPLEX &b);
	friend void operator -=(COMPLEX &a,COMPLEX &b);
	friend void operator *=(COMPLEX &a,COMPLEX &b);
	friend void operator /=(COMPLEX &a,COMPLEX &b);
	void print(COMPLEX &a);

private:
	int r;
	int m;
};

COMPLEX::COMPLEX(double a,double b)
{
	r=a;
	m=b;
}

COMPLEX operator + (COMPLEX &a,COMPLEX &b)
{
	COMPLEX temp;
	temp.r=a.r+b.r;
	temp.m=a.m+b.m;
	return temp;
}

COMPLEX operator - (COMPLEX &a,COMPLEX &b)
{
	COMPLEX temp;
	temp.r=a.r-b.r;
	temp.m=a.m-b.m;
	return temp;
}
COMPLEX operator * (COMPLEX &a,COMPLEX &b)
{
	COMPLEX temp;
	temp.r=a.r*b.r-a.m*b.m;
	temp.m=a.m*b.r+a.r*b.m;
	return temp;
}

COMPLEX operator / (COMPLEX &a,COMPLEX &b)
{
	COMPLEX temp;
	b.m=-b.m;
	temp=a*b;
	temp.m=temp.m/(b.m*b.m+b.r*b.r);
	temp.r=temp.r/(b.m*b.m+b.r*b.r);
	return temp;
}

COMPLEX COMPLEX::operator = (COMPLEX &b)
{
	//COMPLEX temp;
	
	r=b.r;
	m=b.m;

	return *this;
}
void operator += (COMPLEX &a,COMPLEX &b)
{
	a=a+b;
}
void operator -= (COMPLEX &a,COMPLEX &b)
{
	a=a-b;
}
void operator *= (COMPLEX &a,COMPLEX &b)
{
	a=a*b;
}
void operator /= (COMPLEX &a,COMPLEX &b)
{
	a=a/b;
}

void COMPLEX::print(COMPLEX &a)
{
	cout <<a.r<<"+"<<a.m<<"i"<<endl;
}

int main()
{
	COMPLEX a(2,3);
    COMPLEX b(2,1);
	a.print(a);
	a=a+b;
	a.print(a);
	return 0;

}


