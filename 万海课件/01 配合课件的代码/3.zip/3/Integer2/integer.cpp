#include "INTEGER.h"

INTEGER::INTEGER(int i) // ���캯��
{	
	value = i;
}

INTEGER::INTEGER(const INTEGER& other) // �������캯��
{	
	value = other.value;
}

INTEGER operator +(INTEGER left, INTEGER right)	
{	
      INTEGER temp;
      temp.value = left.value + right.value;
      return temp;
}


