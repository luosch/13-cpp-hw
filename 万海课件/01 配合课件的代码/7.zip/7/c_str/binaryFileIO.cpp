// **********************************************************
// c_str.cpp
// ���ܣ�˵������string::c_str�����ļ�����̬����
// **********************************************************

#include <iostream>
#include <fstream>  
#include <string>              
using namespace std;

int main(  )
{
	int a[10]={10,20,30,40,50,60,70,80,90,100};
    int i;
    
	ofstream outFile;                     //��
	string FileName;
      
	cout  << "Please enter the output file name: ";
    cin   >> FileName;
    outFile.open(  FileName.c_str( ), ios::binary );               
	   
	
    for( i = 0; i < 10; i++ ) {
		outFile.write( (char*)&a[i], sizeof( a[i] ) );  //��
	}                              
    outFile.close();                             //��
     
	return 0;
}
