// **********************************************************
// binaryFileIO.cpp
// ���ܣ�˵������C��׼���еĺ������ж������ļ�I/O
// **********************************************************

#include <iostream>
using namespace std;

int main()	
{
    int a[10]={1,2,3,4,5,6,7,8,9,10};
    int b[10];
    int i;
    FILE* fp1, *fp2;                    
    
    fp1=fopen( "c:\\1.dat", "wb" );   
    fwrite(a, sizeof(int), 10, fp1);                                   
    fclose( fp1 );  
	
	fp2=fopen( "c:\\1.dat", "rb" );  
    fread( b, sizeof(int), 10, fp2 ); 
    fclose( fp2 );                       

    for ( i = 0; i < 10; i++)
           cout << b[i] << "  " ;
    
    cout << endl << endl;
    
    return 0;
}


