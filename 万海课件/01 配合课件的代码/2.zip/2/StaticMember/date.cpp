// ***************************************************************
// DATE.cpp
// ��DATE��ʵ���ļ�
// ***************************************************************

#include "DATE.h"
#include <iostream>

using namespace std;

int daysInMonth( int, int );  

int DATE::count = 0;   

DATE::DATE( int initYear, int initMonth, int initDay )
{
     year = initYear;          // �ڹ��캯���н��г�ʼ��
     month = initMonth;
     day  = initDay;

	 count++;

}


DATE::DATE()
{
     year = 2000;
     month = 1;
     day = 1;

	 count++;

}

void DATE::getCount()
{
	cout << "There are " << count << " objects now" << endl;
}


void DATE::set(int newYear, int newMonth, int newDay )
{
    month = newMonth;
    day = newDay;
    year = newYear;
}

int DATE::getMonth() const
{
    return month;
}

int DATE::getDay() const
{
    return day;
}

int DATE::getYear() const
{
    return year;
}

void DATE::print() const
{
    switch (month) {
        case 1 : 
			cout << "January";
			break;
        case 2 : 
			cout << "February";
			break;
        case 3 : 
			cout << "March";
			break;
        case 4 : 
			cout << "April";
			break;
        case 5 : 
			cout << "May";
			break;
        case 6 : 
			cout << "June";
			break;
        case 7 : 
			cout << "July";
			break;
        case 8 : 
			cout << "August";
			break;
        case 9 : 
			cout << "September";
			break;
        case 10 : 
			cout << "October";
			break;
        case 11 : 
			cout << "November";
			break;
        case 12 : 
			cout << "December";
    }
    cout << ' ' << day << ", " << year << endl;
}

void DATE::increment()
{
    day++;
    if (day > daysInMonth(month, year))
    {
        day = 1;
        month++;
        if (month > 12)
        {
            month = 1;
            year++;
        }
    }
}

void DATE::decrement()
{
    day--;
    if ( day == 0 )
    {
        if( month == 1 )
        { 
             day = 31;
             month = 12;
             year--;
        }
        else
        {
             month--;
             day = daysInMonth( month, year );
        }
	}
}

int daysInMonth( int mo, int yr  )
{
	switch (mo)	{
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			return 31;
		case 4: case 6: case 9: case 11:
			return 30;
		case 2:  
			if ((yr % 4 == 0 && yr % 100 != 0) ||yr % 400 == 0)
				return 29;
			else
				return 28;
	}
}
