// ***************************************************************
// DATE.h
// ��DATE��˵���ļ�
// ***************************************************************

class DATE {
public:
	DATE( int, int, int ); // ���캯��
    DATE(); // ȱʡ���캯��

	void set( int, int, int);
	int getMonth() const;
	int getDay() const;
	int getYear() const;
	void print() const;
	void increment();
	void decrement();

	static void getCount( );
    static int count;

private:
    int month;
    int day;
    int year;	
};
