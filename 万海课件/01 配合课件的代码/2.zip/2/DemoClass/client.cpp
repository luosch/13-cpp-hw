// ***************************************************************
// Client.cpp----�ͻ�����
// ***************************************************************

#include "demoClass.h"
#include <iostream>
using namespace std;

int main()
{ 
	DemoClass obj;

	cout << "Now in function main." << endl;

    return 0;
}
