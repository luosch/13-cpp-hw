// ***************************************************************
// demoClass.h
// ��DemoClass��˵���ļ�
// ***************************************************************

#include <iostream> 
#include <string>
using namespace std;

class DemoClass { 
public:
	DemoClass();
    ~DemoClass();
};
