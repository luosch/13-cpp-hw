// ***************************************************************
// DemoClass.cpp
// ��DemoClass��ʵ���ļ�
// ***************************************************************

#include "demoClass.h"
#include <iostream>
using namespace std;

DemoClass::DemoClass()
{
	cout << "Now in Constructor. The object is being created." << endl;
}
 
DemoClass::~DemoClass()
{
	cout << "Now in Deconstructor. The object is deleted" << endl;
}

