// ***************************************************************
// date.h
// ��Date��˵���ļ�
// ***************************************************************

class Date {
public:
	Date( int, int, int ); // ���캯��
    Date(); // ȱʡ���캯��
	~Date();

	void set( int, int, int);
	int getMonth() const;
	int getDay() const;
	int getYear() const;
	void print() const;
	void increment();
	void decrement();

private:
    int month;
    int day;
    int year;	
};
