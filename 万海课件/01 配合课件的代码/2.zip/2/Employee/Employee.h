// ***************************************************************
// Employee.h
// ��Employee��˵���ļ�
// ***************************************************************

#include "date.h"
 
class Employee
{
public:
      Employee( char *, char *, int, int, int, int, int, int );
      void print() const;
      ~Employee();  

private:
      char firstName[ 25 ];
      char lastName[ 25 ];
      
	  Date birthDate;
      Date hireDate; 
 }; 
