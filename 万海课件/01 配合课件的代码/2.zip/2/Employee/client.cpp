// ***************************************************************
// client.cpp
// ��ʾ��Date��ʹ��
// ***************************************************************

#include "Employee.h"
#include <iostream>

using namespace std;

int main()
{
	Employee e( "Bob", "Jones", 7, 24, 1949, 3, 12, 1988 );
    
	e.print();
    
	return 0;  

}
