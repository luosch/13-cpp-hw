// ***************************************************************
// Employee.cpp
// ��Employee��ʵ���ļ�
// ***************************************************************

#include "Employee.h"
#include <iostream>

using namespace std;

Employee::Employee( char *fname, char *lname,                     //Empoyee.cpp
                    int bmonth, int bday, int byear, 
                    int hmonth, int hday, int hyear )     
                  : hireDate(  hmonth, hday, hyear ),               
                    birthDate( bmonth, bday, byear )                
{   
      int length; 

      length = strlen( fname );
	  length = ( length < 25 ? length : 24 );
      strncpy( firstName, fname, length );
      firstName[ length ] = '\0';
      
	  length = strlen( lname );
      length = ( length < 25 ? length : 24 );
      strncpy( lastName, lname, length );
      lastName[ length ] = '\0';
}

void Employee::print() const
{
     cout << lastName << ", " << firstName << "\nHired date: ";
     hireDate.print();
     
	 cout << "Birth date: ";
     birthDate.print();
} 

Employee::~Employee()                               
{  
      cout << "Employee object destructor: " << lastName << ", " << firstName << endl;   
}

