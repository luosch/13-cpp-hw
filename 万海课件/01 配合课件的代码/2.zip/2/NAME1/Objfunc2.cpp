// ����8.3.2
// ����OBJFUNC2.CPP
// ���ܣ���ʾ������Ϊ��������ֵʱ�ĸ����á�

#include <iostream>
using namespace std;

class NAME {
public:
	NAME()
	{
		cout << "Constructing.\n";
		str = NULL;
	}

	~NAME()
	{
		cout << "Destructing.\n";

		if (str != NULL)  
			delete str;

		return;
	}

	void show()
	{
		cout << str << "\n";

		return;
	}

	void set(char* s)
	{
		str = new char[strlen(s) + 1];
		strcpy(str, s);

		return;
	}

private:
	char* str;
};

NAME get_name()
{
	NAME obj;
	char temp_str[250];

	cout << "Input your name: ";
	cin >> temp_str;
	obj.set(temp_str);

	return obj;
}

int main()
{
	NAME myname;

	myname = get_name();

	myname.show();

	return 0;
}

