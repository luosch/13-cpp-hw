//***************************************************************
//DATE.h----��DATE��˵���ļ�
//***************************************************************

class DATE
{
public:
	
	DATE( int initYear, int initMonth, int initDay ); //���캯��
    DATE(); //ȱʡ���캯��

	void Set( int newMonth, int newDay, int newYear  );
	int getMonth() const;
	int getDay() const;
	int getYear() const;
	void Print() const;
	void Increment();
	void Decrement();

private:
    int month;
    int day;
    int year;		
};
