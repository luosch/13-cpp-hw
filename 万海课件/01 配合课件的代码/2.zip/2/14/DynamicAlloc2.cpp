//********************************************************
//��Chap6_20    DynamicAlloc2.cpp
//���ܣ���������new��delete���ж�̬�ڴ������ͷ�
//********************************************************

#include <iostream>
using namespace std;

void inv( int* , int  );

int main()
{
    int *p;
    int Length, i;

    cout << "Enter the lenght you want: ";
	cin >> Length;

	p = new int[ Length ];  //��
	
    cout << "Enter a[0]~a[" << Length-1 << "]:" << endl;
	for( i = 0 ; i < Length; i++ )
		cin >> *(p+i);

	inv( p , Length );

	for( i = 0 ; i < Length; i++ )
		cout << *(p+i) << " ";

	cout << endl;

	delete p;               //��

    return 0;
}

void inv( int* x, int n )
{
	int tmp,i,j;
	int m = ( n-1 )/2;

	for( i = 0; i <= m; i++ )
	{
		j = n - 1 - i;

		tmp = x[i];
		x[i]= x[j];
		x[j]= tmp;
	}
}
