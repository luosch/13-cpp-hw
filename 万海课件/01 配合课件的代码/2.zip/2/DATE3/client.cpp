// ***************************************************************
// client.cpp
// ��ʾ��Date��ʹ��
// ***************************************************************

#include "date.h"
#include <iostream>

using namespace std;

int main()
{
	DATE date1;                
    DATE  date2( 1976, 12, 20 ); 
     
    date1.set(2011,1,1).print();
    date2.set(2012,2,2).set(2013,3,3).print();

	date2.print();

    return 0;
}
