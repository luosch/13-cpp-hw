// ***************************************************************
// date.h
// ��Date��˵���ļ�
// ***************************************************************

class DATE {
public:
	DATE( int, int, int ); // ���캯��
    DATE(); // ȱʡ���캯��

	DATE& set( int, int, int);
	int getMonth() const;
	int getDay() const;
	int getYear() const;
	void print() const;
	void increment();
	void decrement();

private:
    int month;
    int day;
    int year;	
};
