// ***************************************************************
// array.cpp
// ��Array��ʵ���ļ�
// ***************************************************************

#include "array.h"
#include <iostream>

using namespace std;

Array::Array( int initLength )
{
     length = initLength;
     p = new float[length];
     cout << length << " bytes have already allocated." << endl;
}

Array::~Array()
{
     delete []p;
     cout << length << " bytes have been released. Bye." << endl;
}
