// ***************************************************************
// client.cpp
// ʹ����Array���û�����
// ***************************************************************

#include "array.h"
#include <iostream>

using namespace std;

int main()
{
     Array arr(100);
     cout << "This is the end of the program and the object will be destroyed." << endl;

	 return 0;
}
