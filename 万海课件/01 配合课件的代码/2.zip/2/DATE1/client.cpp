// ***************************************************************
// client.cpp
// ��ʾ��Date��ʹ��
// ***************************************************************

#include "Date.h"
#include <iostream>

using namespace std;

int main()
{
	Date date1, date2; //��
    int tmp;
    
	date1.set( 1976, 12, 20 );
    date1.print();
    
	date1.increment();
    date1.print();
    
	date2.set( 1997, 7, 1 );
    date2.print();
    
	date2.decrement();
    date2.print();
    
	tmp = date1.getYear();
    tmp++;
    date1.set( tmp, 12, 20 );
    date1.print();
    
	return 0;
}
