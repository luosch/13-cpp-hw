// ***************************************************************
// date.h
// ��Date��˵���ļ�
// ***************************************************************

class Date {
public:
	void set( int newMonth, int newDay, int newYear  );
	int getMonth() const;
	int getDay() const;
	int getYear() const;
	void print() const;
	void increment();
	void decrement();

private:
    int month;
    int day;
    int year;	
};
