#include <iostream>
#include "Access.h"
using namespace std;

int main()
{
	BASE  obj1;
    Y1    obj2;

    obj2.increment();

    obj2.get_ij();

    obj1.get_ij();

	return 0;
}
