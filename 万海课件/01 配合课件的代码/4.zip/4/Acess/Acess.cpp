#include <iostream>
#include "Access.h"
using namespace std;

BASE::BASE()
{ 
	i=0; 
	j=0; 
	x_temp=0; 
}

void BASE::get_ij()
{
	cout << i << ' '  << j << endl;
}

void Y1::increment()
{
     i++; 
	 j++;	
}
