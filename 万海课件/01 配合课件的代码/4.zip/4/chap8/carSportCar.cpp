// *************************************************************************************
// carSportCar.cpp
// ��ʾ��С�������ܳ�֮��ļ̳й�ϵ
// *************************************************************************************

#include <string>
#include <iostream>

using namespace std;

class Car {
public:
	Car(int Weight,int Speed) // ���캯��
	{   
		weight = Weight;
		speed = Speed;
	}

	void setWeight(int Weight) // ��������
	{
		weight = Weight;
	}

	void setSpeed(int Speed) // �����ٶ�
	{
		speed = Speed;
	}

	int getSpeed() // ��ȡ�ٶ�
	{
		return speed;
	}

	int getWeight() // ��ȡ����
	{
		return weight;
	}

private:
	int weight;
	int speed;
};

class SportCar: public Car {
public:
	SportCar(int Weight,int Speed,string Color):Car(Weight,Speed)
	{
		color = Color;
	}

	void setColor(string Color)
	{
		color = Color;
	}

	string getColor()
	{
		return color;
	}

private:
	string color; // �ܳ�����ɫ
};

int main()
{
	Car car(100,100);
	SportCar sportCar(100,200,"black");                      
	cout << "car's weight is " << car.getWeight() << endl;;
	cout << "car's speed is " << car.getSpeed() << endl;
	cout << "sportcar's weight is " << sportCar.getWeight() << endl;
	cout << "sportcar's speed is " << sportCar.getSpeed() << endl;
	cout << "sportcar's color is " << sportCar.getColor()<< endl;

	return 0;
}
