#ifndef RETANGLE_H
#define RETANGLE_H

#include "Figure.h"

class RECTANGLE: public FIGURE {
public:
	virtual double get_area();
	
};

#endif