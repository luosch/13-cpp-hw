#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Figure.h"

class TRIANGLE: public FIGURE {

public:
	virtual double get_area();
	
};

#endif