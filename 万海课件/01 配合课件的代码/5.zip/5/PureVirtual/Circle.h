#ifndef CIRCLE_H
#define CIRCLE_H

#include "Figure.h"

class CIRCLE: public FIGURE {
public:
	virtual double get_area();

};

#endif