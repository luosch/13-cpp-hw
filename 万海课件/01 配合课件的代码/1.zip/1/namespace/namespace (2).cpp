#include<iostream>
#include<cmath>

int main()
{
	std::cout <<"Hello World!" << std::endl;
	std::cout << sin( 3.14 / 3 ) << std::endl;
	
	return 0;
}