#include <iostream>
using namespace std;

int main()
{
  int   someInt;
  float someFloat;
  char  someChar;

  cout << "the answer is: " << 3*4 << endl; 
  cin  >> someInt  >> someFloat >> someChar ; 
  
  
  cout << someInt << endl;
  cout << someFloat << endl;
  cout << someChar << endl;
  
  return 0;
}

