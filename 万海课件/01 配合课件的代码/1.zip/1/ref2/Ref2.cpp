#include < iostream >
#include < cmath >
using namespace std;

double& f( double x )     //����28
{
    static double y;
	
	x = x+1;
	
	y = sin(x);

	cout << "the address of y in f is: " << &y << endl;
     
	return y;
}


int main()
{
	double a = 3.14/6-1;
	double y;

    y = f( a );

	cout << "y = " << y << endl;

	cout << "the address of y in main is: " << &y << endl;
	
	return 0;
}           
