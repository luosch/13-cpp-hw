#include<iostream>
#include<cmath>

namespace mfc {  //vendor 1��s namespace
	int inflag;    //vendor 1��s inflag
}
namespace owl {  //vendor 2��s namespace
	int inflag;   //vendor 2��s inflag
}

using namespace mfc;
using namespace owl;
using namespace std;

int main()
{
           
   inflag = 3;

   cout << inflag;
           
   return 0;
}
