//******************************************************************
// PrintName program
// This program prints a name in two different formats
//******************************************************************
#include <iostream>
#include <string>

using namespace std;


int main()
{   
    string firstName;    
    string middleName;    
    string lastName;
    string title;
    char middleInitial;
    char letter;

    //valid
    firstName   = "Abraham";
    middleName  = firstName;
    middleName  = "";
    middleName  = "   ";
    lastName    = "Lincoln";
    title       = "President";
    middle      = ' ';
    letter      = middleInitial;

    //invalid    
    /*middleInitial = "A.";
    letter        = firstName;
    firstName     = Thomas;
    "Edison"      = lastName;
    lastName      = ;*/

    return 0;
	
}

